<?php 
include("webclass.php");
$sc=new SiteClass;
?> 
<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="assets/js/color-modes.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.115.4">
    <title>Задание с таблицой</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/sign-in/">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="jqui/jquery-ui.css" rel="stylesheet">
<script src="js/jquery-3.7.1.js"></script>
<script src="jqui/jquery-ui.js"></script>
 
<script>
  $( function() {
    $('#dateChooser').datepicker({dateFormat:'yy-mm-dd'});
  } );
  </script>
  <script>
$(function(){
	$('#table').load('table.php');	
});
</script>
 
<link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

    </style>

    
    <!-- Custom styles for this template -->
    <link href="sign-in.css" rel="stylesheet">
  </head>
   
<main class=" w-50 m-auto">
 
<div id="table">
</div> 
</main>
 
<script src="assets/dist/js/bootstrap.bundle.min.js"></script>
<script>
$( "form" ).on( "submit", function(event) {
  event.preventDefault();
  let table_name= $('#table_name').val();
let name= $('#name').val();
let select= $('#select').val();
let length= $('#length').val();
console.log(name+select+length);
    $.post('getdata.php', {table_name: table_name,name:name,select:select,length:length}, function(data){
      alert(data);
		$('#table').load('table.php');		
    });
} );

</script>

    </body>
</html>
