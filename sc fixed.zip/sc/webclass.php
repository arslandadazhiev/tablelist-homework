<?php 
class SiteClass {
    
	private $conn = ""; 	
    public $table_name="";
    public $row_name="";
    public $select="";
	public function __construct(){
	$this->conn=mysqli_connect("localhost","root","root","mydata");
	}	

	 public function get_data(){
        $sql = "SHOW TABLES";
        $result = $this->conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table>";
            while($rows =mysqli_fetch_row($result)) {
                echo "<h2>$rows[0]</h2>";
               
                $res=mysqli_query($this->conn,"SHOW COLUMNS FROM `$rows[0]` ");
                    if(mysqli_num_rows($res)>0){
                        $i=0;
                          while($row=mysqli_fetch_row($res)){		
                                $i++;
                                echo "
                                <table class=\"table\">
                                        <thead>
                                            <tr>
                                            <th scope=\"col\">#</th>
                                            <th scope=\"col\">Имя столбца</th>
                                            <th scope=\"col\">Тип данных </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                            <th scope=\"row\">$i</th>
                                            <td>$row[0]</td>
                                            <td>$row[1]</td>
                                            </tr>
                                        </tbody>
                                        </table>           
                                ";

                            
                        }
                        echo "
                        <form action=\"getdata.php\" method=\"POST\">
                        <input type=\"hidden\" class=\"form-control\" id=\"table_name\" name=\"table_name\" placeholder=\"Название столбца\" value=\"$rows[0]\">
                        <div class=\"form-group\">
                            <label for=\"exampleInputEmail1\">Название столбца</label>
                            <input type=\"text\" class=\"form-control\" id=\"name\" name=\"row_name\" placeholder=\"Название столбца\" required>
                        </div>
                        <div class=\"form-group\">
                            <label for=\"exampleInputEmail1\">Тип данных</label> <br>
                            <select class=\"form-select\" name=\"select\" id=\"select\" aria-label=\"Default select example\">
                            <option value=\"VARCHAR\">Varchar</option>
                            <option value=\"DATE\">DATE</option>
                            <option value=\"DATETIME\">DATETIME</option>
                            <option value=\"INT\">INT</option>
                          </select>
                          <input type=\"text\" class=\"form-control\" id=\"length\" name=\"length\" placeholder=\"Длинна\">

                        </div>
                   
                         
                        <button type=\"submit\" id=\"sbmbutton\" class=\"btn btn-primary\">Добавить</button>
                        </form>

                        
                        ";
                }

            }
            echo "</table>";
        } else {
            echo "0 results";
        }
        
         
     }
     public function table_select(){
        $sql = "SHOW TABLES";
        $result = $this->conn->query($sql);

        if ($result->num_rows > 0) {
            $i=0;
            while($rows =mysqli_fetch_row($result)) {
                echo "<option value=\"$i++\">$rows[0]</option>";
            }
        }
     }
	 
     public function add($table_name,$row_name,$select,$length){
      
        if(empty($length)&& $select!='DATETIME'){
            echo "будет null";
           mysqli_query($this->conn,"ALTER TABLE $table_name ADD COLUMN $row_name $select null;");
        }
        if(!empty($length)&& $select!='DATETIME'){
          echo "table_name\n".$table_name;
          echo "row_name\n".$row_name;
          echo "select\n".$select;
          echo "length\n".$length;
           mysqli_query($this->conn,"ALTER TABLE $table_name ADD COLUMN $row_name $select($length);");
        } 
        if($select=="DATETIME"){
            
           mysqli_query($this->conn,"ALTER TABLE `$table_name` ADD `$row_name` DATETIME;");
        }
     }
}
 
?> 

 
 <script>
  function showDiv() {
  const select = document.getElementById("select");
  const optionValue = select.options[select.selectedIndex].value;
  
  if (optionValue === "Varchar") {
    document.getElementById("length").style.display = "block";
  } else {
    document.getElementById("length").style.display = "none";
  }
}

document.getElementById("select").addEventListener("change", showDiv);
</script>