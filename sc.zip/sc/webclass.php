<?php 
class SiteClass {
	private $conn = ""; 	
	public function __construct(){
	$this->conn=mysqli_connect("localhost","root","root","mydata");
	}	

	 public function get_data(){
        $sql = "SHOW TABLES";
        $result = $this->conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table>";
            while($rows =mysqli_fetch_row($result)) {
                echo "<h2>$rows[0]</h2>";
               
                $res=mysqli_query($this->conn,"SELECT `id`, `name`, `first_date`, `second_date`, `cost` FROM `$rows[0]` ORDER BY id DESC");
                    if(mysqli_num_rows($res)>0){
                    while($row=mysqli_fetch_row($res)){		
                        echo "
                        
                        <table class=\"table\">
                                <thead>
                                    <tr>
                                    <th scope=\"col\">#</th>
                                    <th scope=\"col\">Имя</th>
                                    <th scope=\"col\">Заказ на </th>
                                    <th scope=\"col\">Сегодняшняя дата </th>
                                    <th scope=\"col\">Цена </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <th scope=\"row\">$row[0]</th>
                                    <td>$row[1]</td>
                                    <td>$row[2]</td>
                                    <td>$row[3]</td>
                                    <td>$row[4]</td>
                                    <td>$row[5]</td>
                                    </tr>
                                </tbody>
                                </table>           
                        ";
                        }
                }

            }
            echo "</table>";
        } else {
            echo "0 results";
        }
        echo $rows[0];
        
         
     }
     public function table_select(){
        $sql = "SHOW TABLES";
        $result = $this->conn->query($sql);

        if ($result->num_rows > 0) {
            $i=0;
            while($rows =mysqli_fetch_row($result)) {
                echo "<option value=\"$i++\">$rows[0]</option>";
            }
        }
     }
	 public function update(){
        $res=mysqli_query($this->conn,"UPDATE `table` SET `id`='[value-1]',`name`='[value-2]',`first_date`='[value-3]',`second_date`='[value-4]',`cost`='[value-5]' WHERE 1");
		 
     }
	 public function add(){
        $name=$_POST['name'];
        $orderdate=$_POST['orderto'];
        $currentdate=date("Y-m-d H:i:s");
        $cost=$_POST['cost'];
        $sel=$_POST['select'];

        if(!empty($name)&& !empty($orderdate) && !empty($cost)&& !empty($sel)){
        $res=mysqli_query($this->conn,"INSERT INTO `$sel`( `name`, `first_date`, `second_date`, `cost`) VALUES ('$name','$orderdate','$currentdate',$cost)");
        }
     }

 
}
 
?> 

<?php 

$sc=new SiteClass;
$sc->add();
?> 
