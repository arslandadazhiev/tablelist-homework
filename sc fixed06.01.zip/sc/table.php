<?php 
include("webclass.php");
$sc=new SiteClass;
?>
<?php $sc->get_data(); ?>