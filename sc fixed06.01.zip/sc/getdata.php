<?php 
include("webclass.php");
$sc=new SiteClass;

$table_name=$_POST['table_name'];
$row_name=$_POST['row_name'];
$select=$_POST['select'];
$length=$_POST['length'];
if($select=="DATETIME"){
    $length=date("Y-m-d H:i:s");  
}
header('Location: index.php');

?>
<?php $sc->add($table_name,$row_name,$select,$length);?>