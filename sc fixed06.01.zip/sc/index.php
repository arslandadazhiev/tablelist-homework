<?php 
include("webclass.php");
$sc=new SiteClass;
?> 
<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="assets/js/color-modes.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.115.4">
    <title>Задание с таблицой</title>
    <link href="jqui/jquery-ui.css" rel="stylesheet">
    <script src="js/jquery-3.7.1.js"></script>
    <script src="jqui/jquery-ui.js"></script>
    <script src="assets/dist/js/bootstrap.bundle.min.js"></script>

  <script>
$(function(){
	$('#table').load('table.php');	
});
</script> 
<link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
  </head>
<main class=" w-50 m-auto">
<div id="table">
</div> 

</main> 
<script>
$( '.myform' ).on( "submit", function(event) {
  event.preventDefault();
  let table_name= $('#table_name').val();
let name= $('#name').val();
let select= $('#select').val();
let length= $('#length').val();
console.log(name+select+length);
    $.post('getdata.php', {table_name: table_name,name:name,select:select,length:length}, function(data){
      $('#table').load('table.php');	
    });
} );

</script>

    </body>
</html>
